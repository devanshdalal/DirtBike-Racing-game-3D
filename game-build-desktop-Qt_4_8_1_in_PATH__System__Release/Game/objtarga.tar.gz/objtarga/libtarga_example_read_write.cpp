#include <stdio.h>
#include <stdlib.h>

#include "libtarga.h"

int main(int argc, char **argv)
{
	if(argc != 2)
	{
		printf("\nUsage : %s <image.tga>\n", argv[0]);
		return 0;
	}
	
	int width;
	int height;
	unsigned char *data;
	
	// read
	data = (unsigned char*)tga_load(argv[1], &width, &height, TGA_TRUECOLOR_24);
	
	if(data == NULL)
	{
		printf("\nError loading tga file.\n");
	}
	else
	{
		printf("\nHeight - %d\nWidth - %d\n", height, width);
	}
	
	// write
	tga_write_raw("copy.tga", width, height, data, TGA_TRUECOLOR_24);
}
