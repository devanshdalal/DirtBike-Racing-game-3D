#include <stdio.h>
#include <stdlib.h>

#include "libtarga.h"

int main()
{
	int width = 800;
	int height = 600;
	
	unsigned char *data = new unsigned char[3*width*height];
	
	// fill example RGB values
	for(int i = 0; i < width*height; i++)
	{
		data[3*i] = (int)(255.0f * (float)i / (float)(width*height)); // r
		data[3*i+1] = (int)(255.0f * (float)i / (float)(width*height)); // g
		data[3*i+2] = (int)(255.0f * (float)i / (float)(width*height)); // b
	}
	
	if (!tga_write_raw("output.tga", width, height, data, TGA_TRUECOLOR_24))
	{
		printf("Failed to write image!\n");
		printf(tga_error_string(tga_get_last_error()));
	}
}
