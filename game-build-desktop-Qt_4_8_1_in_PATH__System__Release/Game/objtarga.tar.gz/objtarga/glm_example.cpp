#include <stdio.h>

#include "glm.h"

GLMmodel *myModel;

int main(int argc, char **argv)
{
  if(argc != 2)
  {
    printf("\nUsage : %s <obj filename>\n", argv[0]);
    return 0;
  }
  
  myModel = glmReadOBJ(argv[1]);
  
  printf("\nNum Vertices\t\t%d", myModel->numvertices);
  printf("\nNum Faces\t\t%d", myModel->numpolygons);
  printf("\nTexture File\t\t:%s", myModel->texture_file);
  
  for(int i = 0; i < myModel->numpolygons; i++)
  {
    GLMpolygon poly = myModel->polygons[i];
    
    int numver = poly.numvertices;
    
    printf("\npolygon %d ->", i);
    
    for(int j = 0; j < numver; j++)
    {
	  // vertex indices
      int vi = poly.vindices[j];
      printf("v(%f,%f,%f) ", myModel->vertices[3*vi], myModel->vertices[3*vi+1], myModel->vertices[3*vi+2]);
      
      if(1 == poly.t) // texture coords are present
      {
        // texture index
        int ti = poly.tindices[j];
        printf("vt(%f,%f) ", myModel->texcoords[2*ti], myModel->texcoords[2*ti+1]);
	  }
    }
  }  
  printf("\n");
  return 0;             /* ANSI C requires main to return int. */
}
